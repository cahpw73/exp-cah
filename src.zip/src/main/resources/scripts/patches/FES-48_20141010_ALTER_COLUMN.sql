--this scripts alter length column address
--@author Christian Alba.

ALTER TABLE SUPPLIER ALTER COLUMN ADDRESS TYPE VARCHAR(500);