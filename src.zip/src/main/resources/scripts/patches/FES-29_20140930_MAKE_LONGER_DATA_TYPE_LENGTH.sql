--this scripts adds status column next tables
--@author Alvaro Cardozo.

ALTER TABLE SCOPE_SUPPLY ALTER COLUMN DESCRIPTION type VARCHAR(510);
