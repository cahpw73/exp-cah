package ch.swissbytes.fqmes.report.util;

/**
 * Created by christian on 16/06/14.
 */
public class ConfigurationReportEnum {
}
