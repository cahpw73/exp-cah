package ch.swissbytes.Service.business.security;

/**
 * Created by alvaro on 7/1/2015.
 */
public class SecurityDao  {
}
