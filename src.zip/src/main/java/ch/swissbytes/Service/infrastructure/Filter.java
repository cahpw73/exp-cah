package ch.swissbytes.Service.infrastructure;

/**
 * Created by alvaro on 9/15/14.
 */
public interface Filter {
    void clean();
}
