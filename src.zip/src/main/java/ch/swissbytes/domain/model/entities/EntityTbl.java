package ch.swissbytes.domain.model.entities;

/**
 * Created by alvaro on 9/22/14.
 */
public interface EntityTbl {

    public Long getId();

    public StatusEntity getStatus();

}
