package ch.swissbytes.domain.interfaces;



/**
 * Created by alvaro on 9/15/14.
 */
public class Record {


}
