package ch.swissbytes.domain.types;

import java.io.Serializable;

/**
 * Created by christian on 16/09/14.
 */
public enum ModeOperationEnum implements Serializable{

    NEW,UPDATE, DELETE,VIEW;


}
