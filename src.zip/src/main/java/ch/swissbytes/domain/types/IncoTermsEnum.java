package ch.swissbytes.domain.types;

import java.io.Serializable;

/**
 * Created by alvaro on 9/30/14.
 */
public enum IncoTermsEnum implements Serializable {


    EXW, FCA, FAS, FOB, CPT, CFR, CIF, CIP, DAT, DAP, DDP


    }
