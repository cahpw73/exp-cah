package ch.swissbytes.domain.types;

import java.io.Serializable;

/**
 * Created by alvaro on 9/30/14.
 */
public enum UoMEnum implements Serializable {

    EACH,KG,L,M,ONLY

}
