package ch.swissbytes.domain.types;

import java.io.Serializable;

/**
 * Created by alvaro on 9/30/14.
 */
public enum TimeMeasurementEnum implements Serializable {

    DAY,WEEK,MONTH ,YEAR;

}
